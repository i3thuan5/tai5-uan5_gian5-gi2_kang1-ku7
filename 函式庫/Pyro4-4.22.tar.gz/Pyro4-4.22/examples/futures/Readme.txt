This is an example that shows the asynchronous function call support
for normal Python functions.

This is just a little extra that Pyro provides, that also works
for normal Python code.

It looks similar to the async proxy support from the `async` example.
