:mod:`Pyro4.message` --- Pyro wire protocol message
===================================================

.. automodule:: Pyro4.message
   :members:

.. attribute:: MSG_*

   The various message types

.. attribute:: FLAGS_*

   Various flags that modify the characteristics of the message
